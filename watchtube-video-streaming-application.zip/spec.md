# Specification

## Summary
**Goal:** Transform search query text into a dot-separated format before sending it to the API, without changing what the user sees in the search input.

**Planned changes:**
- Strip all special characters (non-alphanumeric, non-space) from the search query before it is sent to the API.
- Replace spaces (including multiple consecutive spaces) with dots (`.`) to produce a dot-joined query string (e.g., `can this love` → `can.this.love`).
- Apply this transformation in the query hooks (`useQueries.ts`) or wherever the search term is passed to the external API.
- Leave the search input field display unchanged; only the value forwarded to the API is transformed.

**User-visible outcome:** Users can type a normal search query and it will be correctly sent to the API in dot-separated format, while the search bar continues to show the original text as typed.
