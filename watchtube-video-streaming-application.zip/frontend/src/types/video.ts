export interface Video {
  file_code: string;
  title: string;
  thumbnail: string;
  length: number;
  uploaded?: string; // Date string in format "YYYY-MM-DD HH:mm:ss"
  views?: number; // View count for the video
}

export interface VideoDetail {
  file_title: string;
  file_views: number;
  file_created: string; // Timestamp for upload date/time
  player_img?: string; // Fallback thumbnail
}

export interface VideoDetailApiResponse {
  result?: VideoDetail[];
}
