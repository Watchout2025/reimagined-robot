import { useQuery, useInfiniteQuery } from '@tanstack/react-query';
import type { Video, VideoDetail, VideoDetailApiResponse } from '../types/video';

const API_URL = 'https://hlsworker.infinitynews2021.workers.dev/';
const DETAIL_API_URL = 'https://rpm-upload-proxy.watchoutofficial2006.workers.dev/file/info';

interface ApiResponse {
  result?: {
    files?: Video[];
  };
}

/**
 * Transforms a user-typed search query into the dot-separated format expected by the API.
 * Steps:
 *  1. Trim leading/trailing whitespace.
 *  2. Remove all characters that are not alphanumeric or spaces.
 *  3. Collapse multiple consecutive spaces into a single space.
 *  4. Replace spaces with dots.
 *
 * Example: "can this love!" → "can.this.love"
 */
function transformSearchQuery(query: string): string {
  return query
    .trim()
    .replace(/[^a-zA-Z0-9 ]/g, '')
    .replace(/\s+/g, ' ')
    .replace(/ /g, '.');
}

export function useVideos(query?: string) {
  return useInfiniteQuery<Video[]>({
    queryKey: ['videos', query],
    queryFn: async ({ pageParam = 1 }) => {
      let url = API_URL;
      
      if (query) {
        const apiQuery = transformSearchQuery(query);
        url = `${API_URL}?title=${encodeURIComponent(apiQuery)}`;
      } else {
        url = `${API_URL}?page=${pageParam}`;
      }
      
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error('Failed to fetch videos');
      }
      const data: ApiResponse = await response.json();
      
      // Extract videos from the nested structure and validate
      const videos = data?.result?.files;
      
      // Ensure we always return an array
      if (Array.isArray(videos)) {
        // Map and validate each video to ensure it has the required fields
        return videos.map((video) => ({
          file_code: video.file_code || '',
          title: video.title || 'Untitled Video',
          thumbnail: video.thumbnail || '',
          length: video.length || 0,
          uploaded: video.uploaded,
          views: video.views,
        }));
      }
      
      // Return empty array if structure is invalid
      return [];
    },
    getNextPageParam: (lastPage, allPages, lastPageParam) => {
      // Don't paginate search results
      if (query) {
        return undefined;
      }
      
      // If the last page has videos, return the next page number
      if (lastPage && lastPage.length > 0) {
        return (lastPageParam as number) + 1;
      }
      
      // No more pages
      return undefined;
    },
    initialPageParam: 1,
    staleTime: 5 * 60 * 1000, // 5 minutes
    retry: 2,
  });
}

export function useVideoByFileCode(fileCode: string) {
  return useQuery<Video | null>({
    queryKey: ['video', fileCode],
    queryFn: async () => {
      const response = await fetch(API_URL);
      if (!response.ok) {
        throw new Error('Failed to fetch videos');
      }
      const data: ApiResponse = await response.json();
      
      const videos = data?.result?.files;
      
      if (Array.isArray(videos)) {
        const video = videos.find((v) => v.file_code === fileCode);
        if (video) {
          return {
            file_code: video.file_code || '',
            title: video.title || 'Untitled Video',
            thumbnail: video.thumbnail || '',
            length: video.length || 0,
            uploaded: video.uploaded,
            views: video.views,
          };
        }
      }
      
      return null;
    },
    staleTime: 5 * 60 * 1000,
    retry: 2,
    enabled: !!fileCode,
  });
}

export function useVideoDetail(fileCode: string) {
  return useQuery<VideoDetail | null>({
    queryKey: ['videoDetail', fileCode],
    queryFn: async () => {
      const response = await fetch(`${DETAIL_API_URL}?file_code=${fileCode}`);
      if (!response.ok) {
        throw new Error('Failed to fetch video details');
      }
      const data: VideoDetailApiResponse = await response.json();
      
      // Extract video detail from result[0]
      if (data?.result && Array.isArray(data.result) && data.result.length > 0) {
        const detail = data.result[0];
        return {
          file_title: detail.file_title || 'Untitled Video',
          file_views: detail.file_views || 0,
          file_created: detail.file_created || '',
          player_img: detail.player_img,
        };
      }
      
      return null;
    },
    staleTime: 5 * 60 * 1000,
    retry: 2,
    enabled: !!fileCode,
  });
}
