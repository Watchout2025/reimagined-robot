import { useNavigate } from '@tanstack/react-router';
import { Badge } from '@/components/ui/badge';
import { Clock, ImageOff } from 'lucide-react';
import { useState } from 'react';
import { formatDistanceToNow } from 'date-fns';
import type { Video } from '../types/video';

interface VideoCardProps {
  video: Video;
}

export default function VideoCard({ video }: VideoCardProps) {
  const navigate = useNavigate();
  const [imageError, setImageError] = useState(false);

  const handleClick = () => {
    navigate({ to: '/watch/$fileCode', params: { fileCode: video.file_code } });
  };

  const formatDuration = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    if (hours > 0) {
      return `${hours}:${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    }
    return `${minutes}:${String(secs).padStart(2, '0')}`;
  };

  const formatUploadTime = (uploadedStr?: string): string => {
    if (!uploadedStr) return '';
    try {
      // Parse "YYYY-MM-DD HH:mm:ss" format
      const date = new Date(uploadedStr.replace(' ', 'T'));
      if (isNaN(date.getTime())) return '';
      return formatDistanceToNow(date, { addSuffix: true });
    } catch {
      return '';
    }
  };

  const formatViews = (views?: number): string => {
    if (views === undefined || views === null) return '0 views';
    
    if (views >= 1000000) {
      const millions = views / 1000000;
      return `${millions % 1 === 0 ? millions.toFixed(0) : millions.toFixed(1)}M views`;
    } else if (views >= 1000) {
      const thousands = views / 1000;
      return `${thousands % 1 === 0 ? thousands.toFixed(0) : thousands.toFixed(1)}k views`;
    }
    
    return `${views} views`;
  };

  const handleImageError = () => {
    setImageError(true);
  };

  // Check if thumbnail is missing or invalid
  const hasThumbnail = video.thumbnail && video.thumbnail.trim() !== '';
  const uploadTime = formatUploadTime(video.uploaded);

  return (
    <div
      className="group cursor-pointer overflow-hidden rounded-lg border bg-card text-card-foreground shadow-sm transition-all hover:shadow-lg hover:shadow-primary/20"
      onClick={handleClick}
    >
      <div className="relative aspect-video overflow-hidden bg-muted">
        {hasThumbnail && !imageError ? (
          <img
            src={video.thumbnail}
            alt={video.title}
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
            loading="lazy"
            onError={handleImageError}
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-muted">
            <ImageOff className="h-12 w-12 text-muted-foreground" />
          </div>
        )}
        <Badge
          variant="secondary"
          className="absolute bottom-2 right-2 gap-1 bg-black/80 text-white backdrop-blur-sm"
        >
          <Clock className="h-3 w-3" />
          {formatDuration(video.length)}
        </Badge>
      </div>
      <div className="p-4">
        <h3 className="line-clamp-2 font-semibold leading-tight transition-colors group-hover:text-primary mb-1">
          {video.title}
        </h3>
        {uploadTime && (
          <p className="text-xs text-muted-foreground">
            {formatViews(video.views)} • {uploadTime}
          </p>
        )}
      </div>
    </div>
  );
}
