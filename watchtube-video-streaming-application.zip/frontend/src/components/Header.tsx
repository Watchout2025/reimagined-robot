import { Video, Search } from 'lucide-react';
import { useNavigate, useSearch } from '@tanstack/react-router';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { FormEvent, useState, useEffect } from 'react';

export default function Header() {
  const navigate = useNavigate();
  const searchParams = useSearch({ strict: false }) as { q?: string };
  const [searchQuery, setSearchQuery] = useState(searchParams.q || '');

  useEffect(() => {
    setSearchQuery(searchParams.q || '');
  }, [searchParams.q]);

  const handleLogoClick = () => {
    navigate({ to: '/', search: {} });
    setSearchQuery('');
  };

  const handleSearchSubmit = (e: FormEvent) => {
    e.preventDefault();
    const trimmedQuery = searchQuery.trim();
    if (trimmedQuery) {
      navigate({ to: '/', search: { q: trimmedQuery } });
    } else {
      navigate({ to: '/', search: {} });
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background">
      <div className="container mx-auto flex h-16 items-center justify-between gap-4 px-4">
        <button
          onClick={handleLogoClick}
          className="flex items-center gap-2 text-xl font-bold transition-colors hover:text-primary shrink-0"
        >
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-accent">
            <Video className="h-6 w-6 text-primary-foreground" />
          </div>
          <span className="hidden sm:inline bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            WatchTube
          </span>
        </button>

        <form onSubmit={handleSearchSubmit} className="flex-1 max-w-2xl mx-auto mb-0">
          <div className="relative">
            <Input
              type="text"
              placeholder="Search videos..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-full pr-12 h-[40px]"
            />
            <Button 
              type="submit" 
              size="icon" 
              variant="ghost"
              className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 rounded-full hover:bg-accent"
            >
              <Search className="h-4 w-4" />
              <span className="sr-only">Search</span>
            </Button>
          </div>
        </form>

        <div className="w-10 sm:w-auto shrink-0" />
      </div>
    </header>
  );
}
