import { useSearch } from '@tanstack/react-router';
import { useVideos } from '../hooks/useQueries';
import VideoCard from '../components/VideoCard';
import { Skeleton } from '@/components/ui/skeleton';
import { AlertCircle, Loader2 } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useEffect, useRef, useCallback } from 'react';

export default function HomePage() {
  const searchParams = useSearch({ strict: false }) as { q?: string };
  const activeSearch = searchParams.q || '';
  const { 
    data, 
    isLoading, 
    isError, 
    fetchNextPage, 
    hasNextPage, 
    isFetchingNextPage 
  } = useVideos(activeSearch);

  const observerTarget = useRef<HTMLDivElement>(null);

  // Flatten all pages into a single array of videos
  const videos = data?.pages.flatMap((page) => page) || [];

  // Remove duplicates based on file_code
  const uniqueVideos = videos.reduce((acc, video) => {
    if (!acc.find((v) => v.file_code === video.file_code)) {
      acc.push(video);
    }
    return acc;
  }, [] as typeof videos);

  // Infinite scroll observer
  const handleObserver = useCallback(
    (entries: IntersectionObserverEntry[]) => {
      const [target] = entries;
      if (target.isIntersecting && hasNextPage && !isFetchingNextPage) {
        fetchNextPage();
      }
    },
    [fetchNextPage, hasNextPage, isFetchingNextPage]
  );

  useEffect(() => {
    const element = observerTarget.current;
    if (!element) return;

    const option = {
      root: null,
      rootMargin: '200px',
      threshold: 0,
    };

    const observer = new IntersectionObserver(handleObserver, option);
    observer.observe(element);

    return () => {
      observer.unobserve(element);
    };
  }, [handleObserver]);

  return (
    <div className="min-h-screen">
      <div className="container mx-auto px-4 pt-4 pb-8">
        {isError && (
          <Alert variant="destructive" className="mb-8">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>
              Failed to load videos. Please try again later.
            </AlertDescription>
          </Alert>
        )}

        {isLoading ? (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="space-y-3">
                <Skeleton className="aspect-video w-full rounded-lg" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            ))}
          </div>
        ) : uniqueVideos && uniqueVideos.length > 0 ? (
          <>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {uniqueVideos.map((video) => (
                <VideoCard key={video.file_code} video={video} />
              ))}
            </div>
            
            {/* Infinite scroll trigger */}
            <div ref={observerTarget} className="mt-8 flex justify-center">
              {isFetchingNextPage && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Loader2 className="h-6 w-6 animate-spin" />
                  <span>Loading more videos...</span>
                </div>
              )}
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <AlertCircle className="mb-4 h-16 w-16 text-muted-foreground" />
            <h2 className="mb-2 text-2xl font-semibold">No videos found</h2>
            <p className="text-muted-foreground">
              {activeSearch
                ? 'Try adjusting your search terms'
                : 'No videos available at the moment'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
