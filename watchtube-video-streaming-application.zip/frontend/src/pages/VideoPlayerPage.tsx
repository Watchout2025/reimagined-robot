import { useParams } from '@tanstack/react-router';
import { Card } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { formatDistanceToNow } from 'date-fns';
import { useVideoDetail, useVideos } from '../hooks/useQueries';
import VideoCard from '../components/VideoCard';
import { Loader2, AlertCircle } from 'lucide-react';
import { useEffect, useRef, useCallback } from 'react';

export default function VideoPlayerPage() {
  const { fileCode } = useParams({ strict: false });
  const { data: videoDetail, isLoading, isError } = useVideoDetail(fileCode || '');
  
  // Fetch related videos using the same hook as homepage
  const { 
    data: relatedData, 
    isLoading: isLoadingRelated,
    fetchNextPage, 
    hasNextPage, 
    isFetchingNextPage 
  } = useVideos();

  const observerTarget = useRef<HTMLDivElement>(null);

  // Scroll to top whenever the video changes
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [fileCode]);

  // Flatten all pages into a single array of videos
  const relatedVideos = relatedData?.pages.flatMap((page) => page) || [];

  // Remove duplicates and filter out the current video
  const uniqueRelatedVideos = relatedVideos.reduce((acc, relatedVideo) => {
    if (
      relatedVideo.file_code !== fileCode &&
      !acc.find((v) => v.file_code === relatedVideo.file_code)
    ) {
      acc.push(relatedVideo);
    }
    return acc;
  }, [] as typeof relatedVideos);

  // Infinite scroll observer for related videos
  const handleObserver = useCallback(
    (entries: IntersectionObserverEntry[]) => {
      const [target] = entries;
      if (target.isIntersecting && hasNextPage && !isFetchingNextPage) {
        fetchNextPage();
      }
    },
    [fetchNextPage, hasNextPage, isFetchingNextPage]
  );

  useEffect(() => {
    const element = observerTarget.current;
    if (!element) return;

    const option = {
      root: null,
      rootMargin: '200px',
      threshold: 0,
    };

    const observer = new IntersectionObserver(handleObserver, option);
    observer.observe(element);

    return () => {
      observer.unobserve(element);
    };
  }, [handleObserver]);

  const formatUploadedTime = (createdStr?: string): string => {
    if (!createdStr) return 'Upload time unknown';
    
    try {
      const date = new Date(createdStr);
      
      if (isNaN(date.getTime())) {
        return 'Upload time unknown';
      }
      
      return formatDistanceToNow(date, { addSuffix: true });
    } catch (error) {
      return 'Upload time unknown';
    }
  };

  const formatViews = (views?: number): string => {
    if (views === undefined || views === null) return '0 views';
    
    if (views >= 1000000) {
      const millions = views / 1000000;
      return `${millions % 1 === 0 ? millions.toFixed(0) : millions.toFixed(1)}M views`;
    } else if (views >= 1000) {
      const thousands = views / 1000;
      return `${thousands % 1 === 0 ? thousands.toFixed(0) : thousands.toFixed(1)}k views`;
    }
    
    return `${views} views`;
  };

  return (
    <div className="container mx-auto px-4 pt-4">
      <Card className="overflow-hidden p-0">
        <div className="aspect-video w-full">
          <iframe
            src={`https://watchout.rpmvid.com/#${fileCode}`}
            className="h-full w-full"
            allowFullScreen
            title="Video Player"
          />
        </div>
      </Card>

      <div className="mt-6 mb-8">
        {isLoading ? (
          <>
            <Skeleton className="h-8 w-3/4 mb-3" />
            <Skeleton className="h-5 w-1/4" />
          </>
        ) : isError || !videoDetail ? (
          <>
            <h1 className="text-2xl font-bold text-foreground">Video Player</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              Enjoy your video in full screen for the best experience.
            </p>
          </>
        ) : (
          <>
            <h1 className="text-2xl font-bold text-foreground leading-tight">
              {videoDetail.file_title}
            </h1>
            <p className="mt-2 text-sm text-muted-foreground">
              {formatViews(videoDetail.file_views)} • {formatUploadedTime(videoDetail.file_created)}
            </p>
          </>
        )}
      </div>

      {/* Related Videos Section */}
      <div className="pb-8">
        {isLoadingRelated ? (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="space-y-3">
                <Skeleton className="aspect-video w-full rounded-lg" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            ))}
          </div>
        ) : uniqueRelatedVideos && uniqueRelatedVideos.length > 0 ? (
          <>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {uniqueRelatedVideos.map((relatedVideo) => (
                <VideoCard key={relatedVideo.file_code} video={relatedVideo} />
              ))}
            </div>
            
            {/* Infinite scroll trigger */}
            <div ref={observerTarget} className="mt-8 flex justify-center">
              {isFetchingNextPage && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Loader2 className="h-6 w-6 animate-spin" />
                  <span>Loading more videos...</span>
                </div>
              )}
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <AlertCircle className="mb-4 h-16 w-16 text-muted-foreground" />
            <h2 className="mb-2 text-2xl font-semibold">No related videos found</h2>
            <p className="text-muted-foreground">
              Check back later for more content
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
